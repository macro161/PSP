package lt.mif.oopu2.demen;

public class Car {

    String valstNr;
    String color;
    private String marke;

    public String getValstNr() {
        return valstNr;
    }

    public void setValstNr(String valstNr) {
        this.valstNr = valstNr;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setMarke(String marke) {
        this.marke = marke;
    }

    public String getMarke() {
        return marke;
    }
}
