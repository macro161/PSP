package lt.mif.oopu2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class OopU2Application {

	public static void main(String[] args) {
		ConfigurableApplicationContext cx =	SpringApplication.run(OopU2Application.class, args);
		
		
	}
}
